# lab2_209372363_Paillao
Repositorio del ramo Paradigmas de Programación 2-2023

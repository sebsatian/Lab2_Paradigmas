:- consult('TDAoption_20937236_PaillaoEspindola.pl').
:- consult('TDAflow_20937236_PaillaoEspindola.pl').
:- consult('TDAchatbot_20937236_PaillaoEspindola.pl').
:- consult('TDAuser_20937236_PaillaoEspindola.pl').
:- consult('TDAchatHistory_20937236_PaillaoEspindola.pl').
:- consult('TDAsystem_20937236_PaillaoEspindola.pl').